let nombre="Jhon Jairo Ramirez"
let profesion="Ingeniero" 
alert ("Bienvenido a Punto Gourmet tu nombre es "+nombre)
alert ("Y tu profesion es "+profesion)

